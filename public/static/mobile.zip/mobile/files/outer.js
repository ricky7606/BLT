$(document).ready(function(){
             $(".outer").hide();
        });